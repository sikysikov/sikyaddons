Synopsis
========

This is a metadata add-on for [Kodi/XBMC](http://kodi.tv/) which scrapes movie information from [csfd.cz](http://www.csfd.cz/).

Background
==========

Fork of ekarorgit scrapper https://github.com/ekarorgit/metadata.csfd.cz/

Installation
============


Compatibility
=============

All Kodi/XBMC versions starting from XBMC 11 "Eden" are supported.

Disclaimer
==========

Feel free to report any issues with the scraper, though I don't guarantee that requests will be heard in prompt time.
